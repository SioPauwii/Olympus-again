<?php

interface memberInterface{
    public function editInfo($data);
    public function viewInfo($data);
    public function setAlarm($data);
    public function setSession($data);
    public function calcFoodCalor($data);
    public function calcBodCalcNeed($data);
    public function getRecomm($data);
    public function enrollClass($data);
    public function ViewCoachInfo($data);
    public function isUserEnrolledInClass($data);
    public function dropCoach($data);
}