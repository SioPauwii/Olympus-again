<?php

interface phpmailerInterface{
    public function Expiry();
    public function Session();
    public function Alarm();
}